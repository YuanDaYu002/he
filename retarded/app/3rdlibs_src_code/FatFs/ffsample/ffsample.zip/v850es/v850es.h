#ifndef _V850DEFS
#define _V850DEFS

#pragma ioreg

#define SYSCLK	20000000UL

#endif
